import java.awt.*; 
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;

public class MAP extends JFrame {
	
	public MAP() {
 		setTitle("graph frame");
		setSize(1000,800);
		setLocationRelativeTo(null);	
		setVisible(true);				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	this.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent e) {
				int x=e.getX();
				int y=e.getY();
				String message="("+x+","+y+")";
				System.out.println("Pos:"+message);
			}
			
			@Override
			public void mousePressed(MouseEvent e) {}
			
			@Override
			public void mouseExited(MouseEvent e) {}
			
			@Override
			public void mouseEntered(MouseEvent e) {}
			
			@Override
			public void mouseClicked(MouseEvent e) {}
		});


	}

	public void paint(Graphics g){
		String filepath="..\\boroughs.png"; 
		Image photo=null;
		try{
		photo= ImageIO.read(new File(filepath));
		}catch(Exception e){}
			ImageIcon i = new ImageIcon(photo);
	i.setImage(photo.getScaledInstance(this.getWidth(),this.getHeight()-40, 
            Image.SCALE_AREA_AVERAGING));		
		g.drawImage(i.getImage(), 0, 40, null);
	}	


}