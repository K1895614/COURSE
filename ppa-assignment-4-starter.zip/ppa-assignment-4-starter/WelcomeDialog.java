import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class WelcomeDialog extends JDialog{
	JTextField field;
	JButton button;
	WelcomeDialog (JFrame f,String s){
		super(f,s);
	       Container contents = getContentPane();
		contents.setLayout(new BorderLayout());
		field= new JTextField();
		Font x = new Font("Serif",0,40);
		field.setFont(x);
		 field.setHorizontalAlignment(JTextField.CENTER);
		field.setText("WELCOME");
		button=new JButton("OK");
		getContentPane().add(field,BorderLayout.CENTER);
		getContentPane().add(button,BorderLayout.SOUTH);
		setBounds(100,100,600,400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
		button.addActionListener(new ActionListener(){
			  public void actionPerformed(ActionEvent e){
		        	setVisible(false);
				new AirbnbView();
			}
		});

	}
}
