import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;



public class AirbnbView extends JFrame
{
    private JPanel northPanel;
    private JPanel centerPanel;
    private JPanel southPanel;
    private JTable table= new JTable();
DefaultTableModel model = new DefaultTableModel();
JScrollPane scroll;
String headers[]={"id","name","price"};

AirbnbDataLoader airbnbDataLoader = new AirbnbDataLoader ();
ArrayList<AirbnbListing> dataList;

private int currentPage;  //the number of current page
private int allAmount;  //how many items
private int numInOnePage;  //20 items in one page
private int pageNums;  //how many pages,  allAmount/numInOnePage + 1

String selectedID="";

int fromPrice=20;
int toPrice=1000;

public static void main(String[] args){
   new WelcomeDialog(null,"");
   //new AirbnbView();
}


    public AirbnbView ()
    {
       initUI();
	}

    private void initData(){
dataList=airbnbDataLoader.load(); 
allAmount=dataList.size();
numInOnePage=20;
pageNums=allAmount/numInOnePage + 1;
currentPage=1;
model.setRowCount(0);  //clear exists data
for(int i=0; i<numInOnePage;i++){
//System.out.println(dataList.get(i));
model.addRow(new Object[]{((AirbnbListing)(dataList.get(i))).getId(),((AirbnbListing)(dataList.get(i))).getName(),((AirbnbListing)(dataList.get(i))).getPrice()+""});
}
}


    private void forwardData(){
currentPage++;
if(currentPage>pageNums)  currentPage=1;
model.setRowCount(0);  //clear exists data
int startItemnum=(currentPage-1)*numInOnePage;
for(int i=startItemnum; i<startItemnum+numInOnePage;i++){
//System.out.println(dataList.get(i));
model.addRow(new Object[]{((AirbnbListing)(dataList.get(i))).getId(),((AirbnbListing)(dataList.get(i))).getName(),((AirbnbListing)(dataList.get(i))).getPrice()+""});
}
}

    private void backData(){
currentPage--;
if(currentPage<1)  currentPage=pageNums;
model.setRowCount(0);  //clear exists data
int startItemnum=(currentPage-1)*numInOnePage;
for(int i=startItemnum; i<startItemnum+numInOnePage;i++){
//System.out.println(dataList.get(i));
model.addRow(new Object[]{((AirbnbListing)(dataList.get(i))).getId(),((AirbnbListing)(dataList.get(i))).getName(),((AirbnbListing)(dataList.get(i))).getPrice()+""});
}
}

    private void initUI()
   {
        setTitle("Airbnb");
        setLocation(100, 50);
        setSize(800,600);
        Container contents = getContentPane();
        
        northPanel = new JPanel(new GridLayout(1,6));
	JLabel fromLabel=new JLabel("from");
        JComboBox fromComboBox = new JComboBox(new String[]{"20","50","200","1000"});
	JLabel toLabel=new JLabel("to");
        JComboBox toComboBox = new JComboBox(new String[]{"50","200","1000"});
	JButton confirmButton = new JButton("filter");
        
confirmButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
		new StaticsView(fromPrice,toPrice);
	}
});
fromComboBox.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        if(e.getSource() instanceof JComboBox){
          @SuppressWarnings({ "unchecked", "rawtypes" })
          JComboBox<String> comboBox = (JComboBox)e.getSource();
          String tmp = comboBox.getSelectedItem().toString();
	    fromPrice = Integer.valueOf(tmp);
          System.out.println(fromPrice);
        }
      }
    });
        
toComboBox.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        if(e.getSource() instanceof JComboBox){
          @SuppressWarnings({ "unchecked", "rawtypes" })
          JComboBox<String> comboBox = (JComboBox)e.getSource();
          String tmp = comboBox.getSelectedItem().toString();
	   toPrice = Integer.valueOf(tmp);
          if(toPrice < fromPrice){
             JOptionPane.showMessageDialog(null, "Need Greater than From Price", "Error", JOptionPane.ERROR_MESSAGE);
		toPrice = 1000;
		}
          System.out.println(toPrice );
        }
      }
    });

        northPanel.add(fromLabel);
        northPanel.add(fromComboBox );
        northPanel.add(toLabel);
        northPanel.add(toComboBox );
        northPanel.add(confirmButton );
        
        

        centerPanel = new JPanel();
        model.setColumnIdentifiers(headers);
        table.setModel(model);
        scroll=new JScrollPane(table);
        centerPanel.add(scroll);

        initData();

        southPanel = new JPanel(new BorderLayout());
        JButton mapButton = new JButton("map");
        JButton informationButton = new JButton("information");
	JButton backButton = new JButton("back");
	JButton forwardButton = new JButton("forward");
        southPanel.add(backButton, BorderLayout.WEST);
        southPanel.add(forwardButton , BorderLayout .EAST);
        centerPanel.add(informationButton , BorderLayout .CENTER);
        centerPanel.add(mapButton , BorderLayout .CENTER);
        mapButton.addActionListener(new ActionListener(){
     public void actionPerformed(ActionEvent e){
        MAP map=new MAP();
        map.setVisible(true);
    }
    });
        informationButton.addActionListener(new ActionListener(){
     public void actionPerformed(ActionEvent e){
		AirbnbListing tmp=dataList.get(0);
			System.out.println("get it "+selectedID);

		for(int i=0; i<dataList.size();i++){
		//	System.out.println(((AirbnbListing)dataList.get(i)).getId());

			if(((AirbnbListing)dataList.get(i)).getId().equals(selectedID)){
			tmp=dataList.get(i);
			System.out.println("get it "+selectedID);
			break;
			}
		}

        Airinterview airinterview=new Airinterview(tmp);   
        airinterview.setVisible(true);
    }
});
        backButton.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e){
        backData();
}
});

forwardButton.addActionListener(new ActionListener(){
  public void actionPerformed(ActionEvent e){
        forwardData();
  }
});

        contents.add(northPanel , BorderLayout.NORTH);
        contents.add(centerPanel , BorderLayout.CENTER);
        contents.add(southPanel , BorderLayout.SOUTH); 
        
       // pack();
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

    

table.addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent event)
            {
                    int row = table.rowAtPoint(event.getPoint());
                    int col = table.columnAtPoint(event.getPoint());
			selectedID= (String)						table.getModel().getValueAt(row,col);
System.out.println("selectedID:"+selectedID);
            }
        });
	}

}