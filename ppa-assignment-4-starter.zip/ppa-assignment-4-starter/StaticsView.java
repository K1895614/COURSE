import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
 
public class StaticsView extends JFrame {
    private JPanel northPanel;
    private JPanel centerPanel;
    private JPanel southPanel;
    private JTable table= new JTable();
    DefaultTableModel model = new DefaultTableModel();
    JScrollPane scroll;
    String headers[]={"id","name"};

int fromPrice=20;
int toPrice=1000;

int roomnumber=0;
int homeapartmentnum=0;
	AirbnbDataLoader airbnbDataLoader = new AirbnbDataLoader ();
	ArrayList<AirbnbListing> dataList;
	ArrayList<AirbnbListing> filterDataList;

		AirbnbListing cheapest;
		AirbnbListing expensiveest;
		AirbnbListing shortest;
		AirbnbListing longest;


	 public StaticsView(int fromPrice, int toPrice) {
		this.fromPrice=fromPrice;
		this.toPrice=toPrice;
		 setTitle("Statics");
		 setBounds(400, 300, 800, 600);
		 getContentPane().setLayout(new BorderLayout());
		 JTextArea txt = new JTextArea();
		 dataShow();
		Font x = new Font("Serif",0,18);
		txt.setFont(x);
		txt.setLineWrap(true);    

		 txt.append("From "+fromPrice+" to "+toPrice+" Price\nThe Number of properties is:"+filterDataList.size());
		txt.append("\nPrivate room:"+roomnumber+"\nhomeapartmentnum:"+homeapartmentnum);
		txt.append("\nCheapest:\n"+cheapest.toString());
		txt.append("\nThe most expensive:\n"+expensiveest.toString());

		txt.append("\nLive shortest:\n"+shortest.toString());
		txt.append("\nLive longest:\n"+longest.toString());


		 getContentPane().add(txt,BorderLayout.CENTER);
		 setVisible(true);

	}

       public void dataShow()
	{
		dataList=airbnbDataLoader.load(); 
		filterDataList=new ArrayList();
		cheapest=dataList.get(0);
		expensiveest=dataList.get(0);
		shortest=dataList.get(0);
		longest=dataList.get(0);

		int minPrice=toPrice;
		int maxPrice=fromPrice;

		int minPeriod=365;
		int maxPeriod=0;

		
		for(int i=0;i<dataList.size();i++){
			int price=(((AirbnbListing)(dataList.get(i))).getPrice());
			if(price>=fromPrice && price<=toPrice)
				filterDataList.add(dataList.get(i));
			if(price<minPrice)
			{
				minPrice=price;
				cheapest=dataList.get(i);
			}
			if(price>maxPrice)
			{
				maxPrice=price;
				expensiveest=dataList.get(i);
			}
			int period=365-(((AirbnbListing)(dataList.get(i))).getAvailability365());
			if(period<minPeriod)
			{
				minPeriod=period;
				shortest=dataList.get(i);
			}
			if(period>maxPeriod)
			{
				maxPeriod=period;
				longest=dataList.get(i);
			}


		String room_type=(((AirbnbListing)(dataList.get(i))).getRoom_type());
		    if(room_type.indexOf("room")!=0)
				roomnumber++;
			else
				homeapartmentnum++;
		}
	}



}

