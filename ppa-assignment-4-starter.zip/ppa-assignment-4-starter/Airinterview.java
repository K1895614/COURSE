import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
 
public class Airinterview extends JFrame {
    private JPanel northPanel;
    private JPanel centerPanel;
    private JPanel southPanel;
    private JTable table= new JTable();
    DefaultTableModel model = new DefaultTableModel();
    JScrollPane scroll;
    String headers[]={"id","name"};

AirbnbDataLoader airbnbDataLoader = new AirbnbDataLoader ();
ArrayList<AirbnbListing> dataList;
	public static void main(String[] args){
		new Airinterview();
	}

	 public Airinterview() {
		 setTitle("details");
		 setBounds(400, 300, 800, 600);
		 getContentPane().setLayout(new BorderLayout());
		 JLabel bt = new JLabel();
		 bt.setText("hello");
		 getContentPane().add(bt,BorderLayout.CENTER);
		 setVisible(true);
}

	 public Airinterview(AirbnbListing tmp) {
		 setTitle("details");
		 setBounds(400, 300, 800, 600);
		 getContentPane().setLayout(new BorderLayout());
		 JTextArea bt = new JTextArea("");
		Font x = new Font("Serif",0,28);
		bt.setFont(x);
		 bt.append(tmp.toString());
		 bt.setLineWrap(true);    
		 getContentPane().add(bt,BorderLayout.CENTER);
		 setVisible(true);
}

}

